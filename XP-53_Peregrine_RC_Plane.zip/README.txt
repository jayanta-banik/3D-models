                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3467393
XP-53 Peregrine (RC Plane) by Meremer is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Edit: Added a screenshot of the new working model of the plane. I'll be working on it some more and I'll eventually print it in the coming weeks.

The XP-53 "Peregrine" is a functional RC plane. I have built an almost fully assembled model of the plane (minus the parachute assemblies), however the plane is not quite finished. I have not flown the plane yet, as I am waiting for summer to come around and I'm trying to find a nice wide open space to fly it.

I don't claim to be an expert in the field of aerospace, and to be honest I had no idea what I was doing when I started this project a little over a year ago. However, I have done quite a bit of research and have learned a fair bit about how planes work in that time. This learning curve is the reason why some parts of the plane might not appear super aerodynamic (like the FPV camera holder), and why some of the design decisions I made might not be the best. 

I don't know for certain if it will fly, but I will update this page once I get the chance to give it a test flight. I have put an STL of the full assembly of the plane into Autodesk Flow to find the theoretical drag coefficient (about 0.3 currently; mediocre for a plane but not bad as far as modern cargo vans go :D) as well as the actual drag that the plane experiences as varying speeds and angles of attack. I also created a Google Sheet and used it to auto-run plenty of physics equations relating to the thermodynamics of air, theoretical drag, theoretical lift, and the terminal velocity of the plane with a parachute deployed. I also used a small 1000 g weight scale to measure the static thrust of my working prototype of the Peregrine. Static thrust comes out to be about 5.7 Newtons. According to that, data from Autodesk Flow, and my own calculations, the plane should have more than enough power to fly at speeds of over 50-60 miles per hour minimum. In fact, my calculations show that the plane has a theoretical top speed of just over 100 miles per hour, although I think that 80 or 90 is more realistic. Here's a general run-down of the stats of this plane:

     Total Mass:                    ~1.63 kg
     Static Thrust:                  5.7 N
     Thrust to Weight Ratio:         0.357
     Top Speed:                     ~100 mph
     Cruising Speed (3 degree AoA):  48.6 mph

The plane also has a few contingency plans built into its design for use in case something goes horribly wrong mid-fight. The first contingency plan (Plan B) is to use the self balance mode of the 6-axis gyro in the plane. This will force the plane to try and auto-level itself to prevent crashing. If this doesn't work for some reason, Plan C is the last resort to save the plane from a brisk meeting with the ground (or water, that would be worse). Plan C involves jettisoning a parachute from one of two parachute capsules atop the plane, effectively dropping the plane's terminal velocity to below 10 mph. An impact at this velocity may still damage the plane, but it is certainly better than a 50 mph impact (that impact would have 25 times the amount of kinetic energy behind it!).

Also, the reason I named this plane the XP-53 is to sort of pay tribute to the XP-54, which is a real life plane made by Vultee in the early 1940's for the U.S. Air Force. The XP-54 is structurally similar to my plane, and has its engine in the same position as on mine. Funnily enough, I actually didn't design this plane to be similar to the XP-54, as I had no idea the XP-54 even existed until a few days ago (I've been working on this plane for a lot longer than that). Here's a link to the XP-54's Wikipedia article if you're curious as to what it looks like.

https://en.wikipedia.org/wiki/Vultee_XP-54

I have also included both STL and STEP files of every part and for the full assembly of the plane to allow for both ease of printing and ease of modification.

# Necessary Materials

## Necessary Materials

Since the XP-53 is an RC plane, it naturally required various electronic parts among other things for it to work properly (apart from PLA or ABS plastic of course). Here is a list of everything besides plastic that goes into the Peregrine.

     6x Micro Servo (for control surfaces) - 
https://www.amazon.com/gp/product/B00X7CJZWM/ref=ppx_yo_dt_b_asin_title_o00_s00?ie=UTF8&psc=1

     1x LewanSoul LD-27MG 20kg*cm Servo (for landing gear) - 
https://www.amazon.com/LewanSoul-LD-27MG-Standard-Digital-Aluminium/dp/B07569WJ1M/ref=sr_1_4_sspa?keywords=mini+servo&qid=1551655100&s=gateway&sr=8-4-spons&psc=1

     2x Yards of Ripstop Nylon Fabric (for parachutes) - 
https://www.amazon.com/gp/product/B013FDHAGK/ref=ppx_yo_dt_b_asin_title_o04_s00?ie=UTF8&psc=1

     1x 125 Yard Spool of 10LB Braided Fishing Line (for parachutes) - 
https://www.amazon.com/DERALA-SuperPower-Multifilament-Incredible-Resistant/dp/B076H2R542/ref=sr_1_3?keywords=derala%2Bsuper%2Bpe%2Bbraided%2Bfishing%2Bline&qid=1551661501&s=gateway&sr=8-3-spell&th=1&psc=1

     1x Flysky FS-iA10B Receiver (radio receiver) - 
https://www.amazon.com/gp/product/B07FVBYJJ2/ref=ppx_yo_dt_b_asin_title_o06_s00?ie=UTF8&psc=1

     1x Flysky FS-i6X Transmitter (radio transmitter) - 
https://www.amazon.com/Flysky-FS-i6X-Transmitter-FS-iA6B-Receiver/dp/B0744DPPL8/ref=sr_1_5?keywords=flysky+fs-i6x&qid=1551659009&s=gateway&sr=8-5

     1x 15 Yard Spool of 20 Gauge Stainless Steel Wire (for connecting rear control surfaces - 
https://www.amazon.com/Artistic-20-Gauge-Stainless-Steel-15-Yard/dp/B0063DH2CM/ref=sr_1_6?keywords=stainless%2Bsteel%2Bwire&qid=1551659153&s=gateway&sr=8-6&th=1

     1x Floureon 3s 11.1v 3000mAh LiPo Battery (battery) - 
https://www.amazon.com/FLOUREON-3000mAh-Battery-Airplane-Helicopter/dp/B06Y1ZBZ7K/ref=sr_1_7?crid=3UHY8J5XK9Y27&keywords=3s+lipo+battery+floureon&qid=1551659763&s=gateway&sprefix=3s+lipo+battery+flo%2Caps%2C270&sr=8-7

     1x Hobbyeagle A3 6-axis Gyroscope (for plane stability) - 
https://www.amazon.com/HOBBYEAGLE-Aeroplane-Controller-Stabilizer-Fixed-Wing/dp/B016A69QTI/ref=sr_1_fkmr0_1?keywords=6+axis+gyro+hobbyeagle&qid=1551660293&s=gateway&sr=8-1-fkmr0

     1x 290pcs M3 Hardware Kit (screws, washers, and nuts) - 
https://www.amazon.com/dp/B01K6NNYZ8/ref=dp_cerb_2

     1x 12pcs eBoot 3 Pin PWM Extension Cables (for rudder and elevator servos) - 
https://www.amazon.com/gp/product/B06XCRSD3T/ref=oh_aui_search_asin_title?ie=UTF8&psc=1

     1x 200pcs Assorted Spring Set (for landing gear suspension) - 
https://www.amazon.com/gp/product/B000K7M36W/ref=oh_aui_search_asin_title?ie=UTF8&psc=1

     1x Roll of 3M Electrical Tape (for holding ailerons in place) - 
https://www.amazon.com/Scotch-Electrical-Tape-4-Inch-66-Foot/dp/B001ULCB1O/ref=sr_1_4?keywords=electrical+tape&qid=1551668187&s=hi&sr=1-4

     1x 10pcs Ball Bearing (for landing gear) - 
https://www.amazon.com/gp/product/B072JZ1M5N/ref=oh_aui_search_asin_title?ie=UTF8&psc=1

     1x 2200kv Brushless Motor, ESC, and Propeller Kit (obviously necessary) - 
https://www.amazon.com/gp/product/B01M3UBGU9/ref=oh_aui_search_asin_title?ie=UTF8&psc=1

Alternatively, you can use a smaller 3s LiPo battery as it will save weight (at the cost of flight time). Smaller batteries also make battery installation and connection more easily. Just make sure the battery will fit in the battery compartment of the plane before making a purchase. The dimensions of the compartment are 146mm x 45mm x 22mm. I recommend giving about a millimeter of space on each side so that the battery can slide in easier.

Also, the 290 piece M3 hardware kit should be enough to build the plane, but there's no guarantee. I just used a bunch of M3 stuff that I had lying around to build my prototype. I apologize if this kit isn't enough.

Once I finish printing and building the parachute assemblies, I might make a new section for the description of this plane detailing how to assemble it (it can get tricky).

# Printing Info

## Printing Info

I used a random combination of ABS and PLA to make most of the plane (if you want to use Nylon or something a little fancier, I'm sure it will work). However, the tires that go on the landing gear need to be made of either TPU, TPE, or some other flexible, rubbery thermoplastic. I used TPU, and it seems to work just fine.

If you have trouble printing PLA and/or ABS, here are some great articles I found detailing printing settings for both materials. These have worked really well for me, so I hope they will for you, too.

https://www.sd3d.com/pla-settings/

https://www.sd3d.com/abs-settings/

When it comes to printing with TPU and other flexible filaments, it can get trickier. I've heard that it's very hard to print flexible plastic with printers that employ Bowden style extruders, so that's something to consider before buying that kind of plastic. I'm sure there's some great information out there on TPU printing, but I don't want to recommend something that I don't know will work for sure. So, I will list below the settings that I use to print TPU.

     Layer Height:               0.2 mm
     Initial Layer Height:       0.3 mm
     Line Width:                 0.4 mm
     Initial Layer Line Width:   100%
     Wall Thickness:             1.0 mm
     Outer Wall Wipe Distance:   0.2 mm
     Top/Bottom Thickness:       1.0 mm
     Horizontal Expansion:       0.0 mm
     Z Seam Alignment:           Random
     Infill Density:             100%         (Could be lower if you want the part to be hollow)
     Infill Pattern:             Grid
     Infill Overlap Percentage:  0%
     Printing Temperature:       215 C
     Build Plate Temperature:    60 C
     Diameter:                   1.75 mm
     Flow:                       100%
     Enable Retraction:          Disabled
     Retract At Layer Change:    Disabled
     Print Speed:                30 mm/s
     Top/Bottom Speed:           15 mm/s
     Travel Speed:               60 mm/s
     Initial Layer Speed:        15 mm/s
     Print Acceleration:         2400 mm/s^2
     Travel Acceleration:        3000 mm/s^2
     Print Jerk:                 12 mm/s^3
     Travel Jerk:                20 mm/s^3
     Combing Mode:               All
     Travel Avoid Distance:      2 mm
     Enable Print Cooling:       Enabled
     Fan Speed:                  100%
     Min. Layer Time:            4 s
     Generate Support:           Enabled
     Support Placement:          Everywhere
     Support Overhang Angle:     40 degrees
     Support Pattern:            Lines
     Support Density:            15%
     Support Z Distance:         0.25 mm
     Support X/Y Distance:       1.2 mm
     Build Plate Adhesion Type:  Raft
     Raft Extra Margin:          5 mm
     Raft Air Gap:               0.3 mm
     Initial Z Layer Overlap:    0.15 mm
     Raft Top Layers:            2
     Raft Top Layer Thickness:   0.2 mm
     Raft Top Line Width:        0.3 mm
     Raft Top Spacing:           0.3 mm
     Raft Middle Thickness:      0.2 mm
     Raft Middle Line Width:     0.6 mm
     Raft Middle Spacing:        0.8 mm
     Raft Base Thickness:        0.3 mm
     Raft Base Line Width:       1 mm
     Raft Line Spacing:          2 mm
     Raft Print Speed:           10 mm/s
     Raft Fan Speed:             0%
     Print Sequence:             All at Once

# Known Design Issues

## Known Design Issues

1. The front landing gear seems to be slightly angled, causing the plane to drift to one side when taxiing.

2. There is barely any room for all the wires in the rear of the plane. In order to fix this, I might change the shape of the rear cone, or make either the rear fuselage part or the rear cone longer. I will update this page once I find  suitable fix.

3. Rear landing gear suspension is not stiff enough.

4. Tabs that allow the rear cone to be bolted to the fuselage seem susceptible to breaking (this is due to issue #2 above).